import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventListComponent } from './components/event-list/event-list.component';
import { BookEventComponent } from './components/book-event/book-event.component';

const routes: Routes = [
  {path:'eventList', component: EventListComponent, data:{}},
  {path:'booking', component: BookEventComponent},
  { path: '', redirectTo: '/eventList', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
