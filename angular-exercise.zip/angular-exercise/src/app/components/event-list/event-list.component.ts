import { Component, OnInit } from '@angular/core';
import { EVENTDATALIST } from 'src/eventData';
import { Router, NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css',"./bootstrap.min.css"]
})
export class EventListComponent implements OnInit {
  eventList : [];
  searchText : "";
  constructor(private router:Router) { }

  ngOnInit() {
    this.eventList = EVENTDATALIST;
 console.log(this.eventList);
  }
  openBookingComponent(item:any){
    console.log("Inside openBooking Component Method",item);
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "name": item.name,
          "image": item.image,
          "dateOfEvent":item.dateOfEvent,
          "numberOfSeats":item.numberOfSeats
      }
  };
  this.router.navigate(["booking"], navigationExtras);
  }
}
