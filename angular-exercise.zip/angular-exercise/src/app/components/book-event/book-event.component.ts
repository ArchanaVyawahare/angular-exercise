import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-book-event',
  templateUrl: './book-event.component.html',
  styleUrls: ['./book-event.component.css',"./bootstrap.min.css"]
})
export class BookEventComponent implements OnInit {
  selectedEventItem =  { name: "", image: "", dateOfEvent: "", numberOfSeats: 0 };
bookingObject = { name:"", email:"", phoneNumber:'', numberOfSeats:'', attendee:{attendeeName:"" }};
succeedMsg = false;
bookingForm:FormGroup;
submitted = false;
isAvailableSeat = false;
  constructor(private route : ActivatedRoute,private router :Router,private formBuilder : FormBuilder) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.selectedEventItem.name = params["name"];
      this.selectedEventItem.image = params["image"];
      this.selectedEventItem.dateOfEvent = params["dateOfEvent"];
      this.selectedEventItem.numberOfSeats = params["numberOfSeats"];
  });

  this.bookingForm = this.formBuilder.group({
    userName:['',[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
    email:['',[Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]],
    phone:['',[Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
    seat:['',[Validators.required]],
    attendee:[null]
  });
  this.setAttendeeValidtor();
  }

  setAttendeeValidtor(){
    const attendeeControl = this.bookingForm.get('attendee');
    this.bookingForm.get('seat').valueChanges.subscribe(seat=>{
      if(seat > 1) {
        attendeeControl.setValidators([Validators.required]);
      } 
      attendeeControl.updateValueAndValidity();
    })
    
  }
  generatArray(n: any): any[] {
    return Array(parseInt(n));
  }
  onBookingSubmit(bookingObject : any){
          this.submitted = true;
          if (this.bookingForm.invalid) {
              return;
          }
          this.selectedEventItem.numberOfSeats = this.selectedEventItem.numberOfSeats-bookingObject.numberOfSeats;
          console.log("Tickets is booked for user :: ",bookingObject);
        this.succeedMsg = true;
  }
  onCancelClicked(){
    this.router.navigate(["eventList"]);
  }
    get f() { return this.bookingForm.controls; }

    checkSeatAvailability(noOfSeats : any){
            if(parseInt(noOfSeats) > this.selectedEventItem.numberOfSeats){
              this.isAvailableSeat = true;
            } else {
              this.isAvailableSeat = false;
            }
    }
}


