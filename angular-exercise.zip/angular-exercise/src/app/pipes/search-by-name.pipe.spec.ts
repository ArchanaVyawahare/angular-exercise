import { SearchByNamePipe } from './search-by-name.pipe';

describe('SearchByNamePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByNamePipe();
    expect(pipe).toBeTruthy();
  });
});
