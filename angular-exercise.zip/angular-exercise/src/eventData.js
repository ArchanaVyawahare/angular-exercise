export const EVENTDATALIST = [{
    "name": "Chala Hava yeu dya",
    "image": "https://homepages.cae.wisc.edu/~ece533/images/boat.png",
    "dateOfEvent": "6 june 2019",
    "numberOfSeats": 10
}, {
    "name": "Dance+",
    "image": "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
    "dateOfEvent": "7 june 2019",
    "numberOfSeats": 10
}, {
    "name": "Zee Talkies Awards",
    "image": "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
    "dateOfEvent": "8 june 2019",
    "numberOfSeats": 10
},
{
    "name": "Hirkani Awards",
    "image": "https://homepages.cae.wisc.edu/~ece533/images/cat.png",
    "dateOfEvent": "9 june 2019",
    "numberOfSeats": 10
},
{
    "name": "National Sports Awards",
    "image": "https://homepages.cae.wisc.edu/~ece533/images/fruits.png",
    "dateOfEvent": "10 june 2019",
    "numberOfSeats": 10
}
]